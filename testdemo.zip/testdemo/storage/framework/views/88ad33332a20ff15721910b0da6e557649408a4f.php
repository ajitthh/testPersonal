<!DOCTYPE html>
<html lang="en">
   <head>
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
      <meta charset="utf-8">
      <!-- Title -->
      <title>Project</title>
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- Meta description -->

      <!-- CSS -->
	<link href="<?php echo e(url('assets/css/main.css')); ?>"  rel="stylesheet" type="text/css">
      <!-- Favicon -->
   </head>

    <!-- body start -->
   <body>


      <section class="bnrsection">
	 <div class="container">
	    <div class="row">
	       <div class="offset-lg-1 col-lg-10 col-md-12 col-12 text-center">
	       </div>
	       <div class="offset-lg-2 col-lg-8 offset-md-1 col-md-10 col-12 text-center">
		  <div class="formpart">
		     <form id="myFormId">
			<input type="hidden" name="csrf-token" value="<?php echo e(csrf_token()); ?>">
			<div id="slide01">
			   <h3>Enter Your Personal Details</h3>
			   <div class="mb-3 text-start">
			      <label for="FormControlInput1" class="form-label">First Name</label>
			      <input type="text" class="form-control" name="firstName" id="FormControlInput1" placeholder="First Name" autocomplete="off">
			   </div>
			   <div class="mb-3 text-start">
			      <label for="FormControlInput2" class="form-label">Last Name</label>
			      <input type="text" class="form-control" name="lastName" id="FormControlInput2" placeholder="Last Name" autocomplete="off">
			   </div>
			   <div class="mb-3 text-start">
			      <label for="FormControlInput3" class="form-label">Enter Your Date of Birth</label>
			      <fieldset>
				 <legend> Date Of Birth</legend>
				 <div class="row">
				    <div class="form-group col-lg-4 col-md-4 col-sm-4 col-12 ">
				       <select name="lstDobDay" id="lstDobDay" class="form-control watermark">
					     <option value="">Day </option>	
						<?php for($i = 1; $i <= 31; $i++): ?>
                                                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                                <?php endfor; ?>
					  </select>
				       <i class="validate " aria-hidden="true" style="display:none;"></i>
				       <span id="dobDay_err" class="error_msg error"></span>
				    </div>
				    <div class="form-group col-lg-4 col-md-4 col-sm-4 col-12 ">
				       <select name="lstDobMonth" id="lstDobMonth" class="form-control watermark">
					  <option value="">Month </option>
					  <option value="1">January</option>
					  <option value="2">February</option>
					  <option value="3">March</option>
					  <option value="4">April</option>
					  <option value="5">May</option>
					  <option value="6">June</option>
					  <option value="7">July</option>
					  <option value="8">August</option>
					  <option value="9">September</option>
					  <option value="10">October</option>
					  <option value="11">November</option>
					  <option value="12">December</option>
				       </select>
				       <i class="validate " aria-hidden="true" style="display:none;"></i>
				       <span id="dobMonth_err" class="error_msg"></span>
				    </div>
				    <div class="form-group col-lg-4 col-md-4 col-sm-4 col-12">
				       <select name="lstDobYear" id="lstDobYear" class="form-control">
					     <option value="">Year</option>
						<?php for($i = 1900; $i <= 2024; $i++): ?>
        						<option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
    						<?php endfor; ?>
				       </select>
				       <i class="validate " aria-hidden="true" style="display:none;"></i>
				       <span id="dobYear_err" class="error_msg"></span>
				    </div>
				    <span id="dob_final_err" class="error_msg"></span>
				 </div>
			      </fieldset>
			   </div>
			   <div class="mb-3 text-center">
			      <button type="button" class="btn btn-warning next01">Next</button>
			   </div>
			</div>
			<div id="slide02" style="display:none;">
			   <h3>Enter Your Contact Details</h3>
			   <div class="mb-3 text-start">
			      <label for="FormControlInput4" class="form-label">Email Address</label>
			      <input type="email" class="form-control" name="emailId" id="FormControlInput4" placeholder="Email Address" autocomplete="off">
			   </div>
			   <div class="mb-3 text-start">
			      <label for="FormControlInput5" class="form-label">Phone Number</label>
			      <input type="text" class="form-control" name="phoneNo" id="FormControlInput5" placeholder="Phone Number" autocomplete="off">
			   </div>
			   <div class="mb-3 text-center">
			      <button type="submit" class="btn btn-success" id="submit_claim">Submit</button>
			   </div>
			</div>
		     </form>
		  </div>
	       </div>
	    </div>
	 </div>
      </section>

	<script src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>
   </body>
    <!--body end -->

</html>
<?php /**PATH /mnt/my_partition/var/www/html/testdemo/resources/views/index.blade.php ENDPATH**/ ?>