<?php

namespace App\Models;

use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class BaseMongoModel extends Eloquent
{
    protected $connection = 'mongodb';
}
?>
