<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Jenssegers\Agent\Facades\Agent;
use App\Models\PersonalDetails;
use App\Models\AddressDetails;
use Log;
class PersonalController extends Controller
{
	/**
	 * To add personal Details
	 * */
	public function addPersonalData(Request $request){
		parse_str($request->formdata, $data);
		$clientIP 	= \Request::ip();
		$browser 	= Agent::browser();
		$userAgent	= $_SERVER['HTTP_USER_AGENT'];
		$PersonalData  	=  new PersonalDetails();
		$PersonalData->firstName	= $data['firstName'];
		$PersonalData->lastName		= $data['lastName'];
		$PersonalData->dob		= $data['lstDobDay']."/".$data['lstDobMonth']."/".$data['lstDobYear'];
		$PersonalData->email		= $data['emailId'];
		$PersonalData->phoneNumber	= $data['phoneNo'];
		$PersonalData->ipAddress	= $clientIP;	
		$PersonalData->userAgent	= $userAgent;
		$PersonalData->browser		= $browser;
		if(Agent::isTablet()){
			$PersonalData->deviceType= "Tablet";
		}else if(Agent::isDesktop()){
			$PersonalData->deviceType="Desktop";
		}else if(Agent::isPhone()){
			$PersonalData->deviceType="Phone";
		}
		$PersonalData->save();
		return $PersonalData;
	}

	/**
	 * calling the view
	 * */
	public function prevAddress($id,$name){
		return view('pageTwo')->with('id',$id)->with('firstname',$name);
	}

	/**
	 * To add address Data
	 * */
	public function addAddressData(Request $request){
		parse_str($request->formdata, $data);
		foreach($data['address1'] as $key => $val){
			$addressDetails=AddressDetails::updateOrCreate([
				'addressLine1' => $val,
				'addressLine2'=>$data['address2'][$key],
				'addressLine3'=>$data['address3'][$key],
				'personalId'=>$data['pid']
			],[
				'addressLine1' => $val,
				'addressLine2'=>$data['address2'][$key],
				'addressLine3'=>$data['address3'][$key],
				'personalId'=>$data['pid']					
			]);
		}
		return 1;
	}

	/**
	 * calling the view
	 * */
	public function thankyou(){
		return view('thankyou');	
	}

	/**
	 * To check the duplication of mail and phone no
	 * */
	public function mailPhoneCheck(Request $request){
		$mailData   = PersonalDetails::where("email",$request->email)->count();	
		$phoneData   = PersonalDetails::where("phoneNumber",$request->phone)->count();
		$checkArray=array();
		if($mailData>0){
			$checkArray['mail']=1;
		}else{
			$checkArray['mail']=0;
		}
		if($phoneData>0){
			$checkArray['phone']=1;
		}else{
			$checkArray['phone']=0;
		}
		return json_encode($checkArray);
	}
}

?>

