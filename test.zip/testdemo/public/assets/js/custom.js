$(".next01").on("click",function(){
	if(!$("#FormControlInput1").val()){
		alert("Please enter the first name");
		$("#FormControlInput1").focus();
		return false;
	}
	if(!$("#FormControlInput2").val()){
		alert("Please enter the last name");
		$("#FormControlInput2").focus();
		return false;
	}
	if(!$("#lstDobDay").val()){
		alert("Please select the day");
		$("#lstDobDay").focus();
		return false;
	}
	if(!$("#lstDobMonth").val()){
		alert("Please select the month");
		$("#lstDobMonth").focus();
		return false;
	}
	if(!$("#lstDobYear").val()){
		alert("Please select the year");
		$("#lstDobYear").focus();
		return false;
	}
	$("#slide01").hide(),$("#slide02").show();
});

$("#myFormId").submit(function( event ) {
	var formdata = $(this).serialize();
	if(!$("#FormControlInput4").val()){
		alert("Please enter the email");
		$("#FormControlInput4").focus();
		return false;
	}
	var regex =/^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!regex.test($("#FormControlInput4").val())) {
		alert("Please enter a valid email");
		$("#FormControlInput4").focus();
		return false;
	}
	if(!$("#FormControlInput5").val()){
		alert("Please enter the phone number");
		$("#FormControlInput5").focus();
		return false;
	}

	var phone_pattern = /([0-9]{10})|(\([0-9]{3}\)\s+[0-9]{3}\-[0-9]{4})/; 
	if(!phone_pattern.test($("#FormControlInput5").val())){
		alert("Please enter a valid phone no");
		$("#FormControlInput5").focus();
		return false;
	}

	var email =$("#FormControlInput4").val();
	var phone = $("#FormControlInput5").val()
	$.ajax({
		headers: {
			'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
		},
		url: '/mailPhoneCheck',
		type: 'POST',
		async: true,
		dataType: 'json',
		data:{
			"email":email,
			"phone":phone
		},
		success: function (data1) {
			if(data1.mail==1){
				alert("Email Id already Exist");
				$("#FormControlInput4").focus();
				$('#submit_claim').prop('disabled', false);
				return false;
			}
			if(data1.phone==1){
				alert("Phone number already Exist");
				$("#FormControlInput5").focus();
				$('#submit_claim').prop('disabled', false);
				return false;
			}
			if(data1.mail!=1 && data1.phone!=1){
				$.ajax({
					headers: {
						'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
					},
					url: '/addPersonalData',
					type: 'POST',
					async: true,
					dataType: 'json',
					data:{ 
						"formdata":formdata
					},
					success: function (data) {
						console.log(data);
						console.log(data._id);
						var id=data._id;
						var fname=data.firstName;
						window.location.href ="/prevAddress/"+id+"/"+fname;
					},
				});		
			}
		},
	});

	$('#submit_claim').prop('disabled', true);
	event.preventDefault();
});

$('#flexRadioDefault1').click(function() {
	if($('#flexRadioDefault1').is(':checked')) { 
		$("#slide03").css("display","none");
		$("#slide04").css("display", "block"); 
	}
});
$('#flexRadioDefault2').click(function() {
	if($('#flexRadioDefault2').is(':checked')) {
		window.location.href ="/thankyou";
	}
});

$('#back02').click(function() {
	$("#slide03").css("display","block");
	$("#slide04").css("display", "none");
});


var j=2;
$("#showadrs2").click(function() {
	$(".addDiv").append('<div class="childDiv"><label class="form-label">Previous Address</label><input type="text" class="form-control mb-3" name="address1[]" placeholder="Address line 1" autocomplete="off"><input type="text" class="form-control mb-3" name="address2[]" placeholder="Address line 2" autocomplete="off"><input type="text" class="form-control mb-3" name="address3[]" placeholder="Address line 3" autocomplete="off"></div>');
	if(j>=2){
		$("#remove4").css("display", "block");
		$("#back02").css("display", "none");
	}else{
		$("#remove4").css("display", "none");
	}
	j++;
});

$('#remove4').click(function(event) {
	$(".childDiv:last-child").remove();
	if($(".addDiv").children().length == 0)
	{
		$("#remove4").css("display", "none");
	}
}
);

$("#addressFormId").submit(function( event ) {
	var formdata = $(this).serialize();
	if(!$("#address1").val()){
		alert("Please Enter the data");
		return false;
	}
	$('#addressSubmit').prop('disabled', true);
	$.ajax({
		headers: {
			'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')
		},
		url: '/addAddressData',
		type: 'POST',
		dataType: 'json',
		data:{
			"formdata":formdata
		},
		success: function (data) {
			window.location.href ="/thankyou";
		}
	});
	event.preventDefault();
});
