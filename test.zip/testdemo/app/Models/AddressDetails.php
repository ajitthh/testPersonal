<?php

namespace App\Models;

use App\Models\BaseMongoModel;

class AddressDetails extends BaseMongoModel
{
    protected $table = 'AddressDetails';

    public $timestamps = true;

    protected $fillable = [
        'addressLine1',
        'addressLine2',
        'addressLine3',
        'personalId'
    ];

    protected $guarded = [];

}

