<?php

namespace App\Models;

use App\Models\BaseMongoModel;

class PersonalDetails extends BaseMongoModel
{
    protected $table = 'PersonalDetails';

    public $timestamps = true;

    protected $fillable = [
        'firstName',
        'lastName',
	'dob',
	'email',
	'phoneNumber'
    ];

    protected $guarded = [];

        	
}
