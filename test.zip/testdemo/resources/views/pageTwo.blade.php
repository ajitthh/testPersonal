<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <!-- Title -->
      <title>Project</title>
      <meta name="csrf-token" content="{{ csrf_token() }}">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- Meta description -->
     
      <!-- CSS -->
      <link href="{{ url('assets/css/main.css') }}" rel="stylesheet" type="text/css">
      <!-- Favicon -->
      <!-- <link rel="icon" type="image/png" href="dist/img/favicon.ico"> -->
   </head>
    
    <!-- body start -->
   <body>

      <section class="bnrsection">
         <!-- <div class="container-fluid">
            <div class="row">
               <div class="col-lg-12 p-0">
                  <img src="dist/img/bnr.jpg" alt="">
               </div>
            </div>
         </div> -->
         <div class="container">
            <div class="row">
               <div class="offset-lg-2 col-lg-8 offset-md-1 col-md-10 col-12 text-center">
                  <div class="formpart">
		     <form id="addressFormId">
 			<input type="hidden" name="csrf-token" value="{{ csrf_token() }}">
                        <div id="slide03" style="display: block;">
                           <h3>Do you have a Previous Address?</h3>
                           <div class="form-check">
                            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1">
                            <label class="form-check-label next02" for="flexRadioDefault1">
                              Yes
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                            <label class="form-check-label tothank" for="flexRadioDefault2">
                              No
                            </label>
                          </div>
                        </div>
                        
                        
                        
                        
                        <div id="slide04" style="display:none;">
                           <h3>Enter your Previous Address</h3>
                            <div class="mb-3 text-start" id="addDiv">
                                <label class="form-label">Previous Address 1</label>
                                <input type="text" class="form-control mb-3" id="address1" name="address1[]" placeholder="Address line 1" autocomplete="off">
                                <input type="text" class="form-control mb-3" name="address2[]" placeholder="Address line 2" autocomplete="off">
				<input type="text" class="form-control mb-3" name="address3[]" placeholder="Address line 3" autocomplete="off">
				<div class="addDiv"></div>
                            </div>
                           
                            <div class="mb-3 text-center" id="submitoradd01">
				<button type="submit" id="addressSubmit" class="btn btn-success tothank">Submit</button>
				<input type="hidden" class="form-control mb-3" name="pid" value="{{$id}}">
				<p><a href="#" id="showadrs2">Add Another Address</a></p>
				<p><a href="#" id="remove4" style="display:none;">Remove Address</a></p>
                                <p><a href="#" id="back02"><< Back</a></p>
                            </div> 

                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </section>

	<script src="{{ url('assets/js/jquery.min.js')}}"></script>
        <script src="{{ url('assets/js/custom.js')}}"></script>
   </body>
    <!--body end -->
    
</html>
